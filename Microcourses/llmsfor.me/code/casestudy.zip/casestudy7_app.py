import streamlit as st
from openai import OpenAI

# Instantiate the client
client = OpenAI()

# Title of the app
st.title("Devil May Care Clinic Chatbot 😈")

# Displaying text
st.write("Welcome to the Devil May Care Clinic Chatbot! Ask me anything about your health and I'll do my best to help you out.")

# Create a chat input
if prompt := st.chat_input("Say something"):
    with st.chat_message("user", avatar="patient_avatar.jpg"):
        st.markdown(prompt)

    # Get the response from OpenAI
    response = client.chat.completions.create(messages=[{"role": "user", "content": prompt}], model="gpt-4o-mini")
    response_text = response.choices[0].message.content

    # Write out
    with st.chat_message("assistant", avatar="doctor_avatar.jpg"):
        st.markdown(response_text)
