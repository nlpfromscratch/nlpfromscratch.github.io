import streamlit as st
from openai import OpenAI

# Instantiate the client
client = OpenAI()

# Title of the app
st.title("Hello, World! in Streamlit")

# Displaying text
st.write("Welcome to your first Streamlit app!")

# Create a chat input
if prompt := st.chat_input("Say something"):
    with st.chat_message("user"):
        st.markdown(prompt)

    # Get the response from OpenAI
    response = client.chat.completions.create(messages=[{"role": "user", "content": prompt}], model="gpt-4o-mini")
    response_text = response.choices[0].message.content

    # Write out
    with st.chat_message("assistant"):
        st.markdown(response_text)
