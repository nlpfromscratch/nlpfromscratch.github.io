import streamlit as st
from openai import OpenAI

system_prompt = "You are the Devil May Care Clinic Chatbot, a virtual assistant designed to answer questions from patients."

# Instantiate the client
client = OpenAI()

# Title of the app
st.title("Devil May Care Clinic Chatbot 😈")

# Displaying text
st.write("Welcome to the Devil May Care Clinic Chatbot! Ask me anything about your health and I'll do my best to help you out.")

# Initialize the messages array with the system prompt
messages = [{"role": "system", "content": system_prompt}]

# Create a chat input
if prompt := st.chat_input("Say something"):
    with st.chat_message("user", avatar="patient_avatar.jpg"):
        st.markdown(prompt)

    # Add user prompt to messages array
    messages.append({"role": "user", "content": prompt})

    # Get the response from OpenAI
    response = client.chat.completions.create(messages=messages, model="gpt-4o-mini")
    response_text = response.choices[0].message.content

    # Write out
    with st.chat_message("assistant", avatar="doctor_avatar.jpg"):
        st.markdown(response_text)
