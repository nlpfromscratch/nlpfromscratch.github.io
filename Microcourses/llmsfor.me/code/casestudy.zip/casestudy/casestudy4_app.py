import streamlit as st

# Title of the app
st.title("Hello, World! in Streamlit")

# Displaying text
st.write("Welcome to your first Streamlit app!")

# Create a chat input
if prompt := st.chat_input("Say something"):
    with st.chat_message("user"):
        st.markdown(prompt)