import streamlit as st

# Title of the app
st.title("Hello, World! in Streamlit")

# Displaying text
st.write("Welcome to your first Streamlit app!")

# Create a chat input
prompt = st.chat_input("Say something")
print(prompt)
st.markdown(prompt)