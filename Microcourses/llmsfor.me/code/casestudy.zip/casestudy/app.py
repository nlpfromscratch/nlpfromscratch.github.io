import streamlit as st
from openai import OpenAI

# System prompt
system_prompt = \
"""
You are the Devil may Care Clinic Network LLM Assistant.
You are designed to answer questions from patients and clients of
the Devil May Care Health Network.
You are not a doctor, your advice is not official medical advice.
If someone asks where the name of the clinic network comes from
you can tell them its from the novel by Sebastian Faulks and then
point them to the wikipedia page here: https://en.wikipedia.org/wiki/Devil_May_Care_(Faulks_novel)
"""

# Instantiate the messages array
# Check if 'messages' exists in session state
if 'messages' not in st.session_state:
    st.session_state.messages = [
        {"role": "system", "content": system_prompt}
    ]

# Instantiate the OpenAI client
client = OpenAI(base_url="http://localhost:11434/v1",
                api_key="ollama")

# Create the title
st.title("Devil May Care Clinic 😈 Virtual LLM Assistant")

# Create a text
st.write("This is the Devil May Care Clinic 😈 Virtual LLM Assistant. You can ask me anything about the Devil May Care Clinic Network.")

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])

# Create the text input
if prompt := st.chat_input("Please enter a prompt."):
    with st.chat_message("user", avatar="patient_avatar.jpg"):
        st.write(prompt)

    # 1. Append the user prompt messages array using the prompt
    st.session_state.messages.append(
        {"role": "user", "content": prompt}
    )

    # 2. Make the request to OpenAI with the prompt / messages array
    response = client.chat.completions.create(
        messages=st.session_state.messages,
        model="llama3.2"
    )

    print(response)

    # 3. Get the text response
    response_text = response.choices[0].message.content

    # 4. Write the response in the chat
    with st.chat_message("assistant", avatar="doctor_avatar.jpg"):
        st.write(response_text)

    st.session_state.messages.append(
        {"role": "assistant", "content": response_text}
    )


